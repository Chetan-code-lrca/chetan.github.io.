

import psycopg2
from psycopg2.extras import RealDictCursor  # For dictionary-like cursor

def connect_db():
    try:
        conn = psycopg2.connect(
            host="localhost",
            database="smart_study_planner",
            user="postgres",
            password="pass",
            port=5432  # default PostgreSQL port
        )
        return conn
    except Exception as e:
        print("Connection error:", e)
        return None

# Usage:
# conn = connect_db()
# cursor = conn.cursor(cursor_factory=RealDictCursor)
