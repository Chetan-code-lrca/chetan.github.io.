from db_connection import connect_db
from datetime import datetime
from tabulate import tabulate
import getpass
from decimal import Decimal

c = connect_db()
cursor = c.cursor()

# ---------------- Teacher Entry ----------------
def teacher_entry():
    while True:
        print("\n--- TEACHERS MENU ---")
        print("1. Login")
        print("2. Register")
        print("3. Exit")
        try:
            choice = int(input("Choose option: "))
        except ValueError:
            print("Invalid input. Enter a number.")
            continue

        if choice == 1:
            login_teacher()
        elif choice == 2:
            register_teacher()
        elif choice == 3:
            break
        else:
            print("Invalid choice.")

# ---------------- Register/Login ----------------
def register_teacher():
    print("\n--- TEACHER REGISTRATION (Pending Approval) ---")
    name = input("Enter your name: ")
    username = input("Enter a username: ")
    password = getpass.getpass("Enter password: ")
    contact = input("Enter contact: ")
    college = input("Enter college: ")
    qualification = input("Enter qualification: ")
    email = input("Enter email: ")
    designation = input("Enter designation: ")
    specialisation = input("Enter specialisation: ")
    try:
        experience = int(input("Enter years of experience: "))
    except ValueError:
        experience = 0

    try:
        cursor.execute("SELECT user_name FROM teacher_login WHERE user_name=%s", (username,))
        if cursor.fetchone():
            print("Username already exists. Choose another.")
            return
        cursor.execute("SELECT user_name FROM teacher_requests WHERE user_name=%s", (username,))
        if cursor.fetchone():
            print("Username already requested and awaiting approval.")
            return

        query = """INSERT INTO teacher_requests
                   (name, user_name, password, contact, college, qualification, email, designation, specialisation, experience, status)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'pending')"""
        values = (name, username, password, contact, college, qualification, email, designation, specialisation, experience)
        cursor.execute(query, values)
        c.commit()
        print("Registration request submitted. Please wait for admin approval.\n")
    except Exception as e:
        print("Registration failed:", e)

def login_teacher():
    username = input("Username: ")
    password = getpass.getpass("Password: ") 
    cursor.execute("SELECT teacher_id, Name FROM teacher_login WHERE user_name=%s AND password=%s",
                   (username, password))
    teacher = cursor.fetchone()
    if teacher:
        print(f"\nWelcome {teacher[1]}")
        teacher_menu(teacher[0])
    else:
        print("Invalid credentials")

# ---------------- Teacher Menu ----------------
def teacher_menu(teacher_id):
    while True:
        print("\n1. Add Subject\n2. Delete Subject\n3. Add Topic\n4. Delete Topic")
        print("5. Create Exam (6 Questions)\n6. Delete Exam\n7. View Student Progress\n8. edit profile\n9. logout")
        try:
            choice = int(input("Enter choice: "))
        except ValueError:
            print("Invalid input. Enter a number.")
            continue

        if choice == 1:
            add_subject(teacher_id)
        elif choice == 2:
            delete_subject(teacher_id)
        elif choice == 3:
            add_topic(teacher_id)
        elif choice == 4:
            delete_topic(teacher_id)
        elif choice == 5:
            create_exam(teacher_id)
        elif choice == 6:
            delete_exam(teacher_id)
        elif choice == 7:
            teacher_view_progress()
        elif choice == 8:
            edit_teacher_profile(teacher_id)
        elif choice == 9:
            break
        else:
            print("Invalid choice.")

# ---------------- Subject Handling ----------------
def check_date():
    while True:
        date_str = input("Enter exam date (YYYY-MM-DD): ")
        try:
            exam_date = datetime.strptime(date_str, "%Y-%m-%d").date()
            if exam_date < datetime.today().date():
                print("Error: Date cannot be in the past.")
            else:
                return date_str
        except:
            print("Invalid date format.")

def add_subject(teacher_id):
    subject = input("Subject name: ")
    exam_date = check_date()
    try:
        cursor.execute("INSERT INTO subjects(Name, exam_date, teacher_id) VALUES(%s,%s,%s)",
                       (subject, exam_date, teacher_id))
        c.commit()
        print("Subject added successfully!")
    except Exception as e:
        print("Failed to add subject:", e)

def delete_subject(teacher_id):
    cursor.execute("SELECT subject_id, Name FROM subjects WHERE teacher_id=%s", (teacher_id,))
    subjects = cursor.fetchall()
    if not subjects:
        print("No subjects to delete.")
        return
    for s in subjects:
        print(f"{s[0]} - {s[1]}")
    subject_id = input("Enter subject_id to delete: ")
    confirm = input("Are you sure? This will delete all topics, assessments, MCQs, and student assessments. (y/n): ").lower()
    if confirm != 'y':
        return

    try:
        cursor.execute("SELECT topic_id FROM topics WHERE subject_id=%s", (subject_id,))
        topics = cursor.fetchall()
        for t in topics:
            topic_id = t[0]
            cursor.execute("SELECT assessment_id FROM assessments WHERE topic_id=%s", (topic_id,))
            assessments = cursor.fetchall()
            for a in assessments:
                cursor.execute("DELETE FROM mcq_options WHERE assessment_id=%s", (a[0],))
            cursor.execute("DELETE FROM assessments WHERE topic_id=%s", (topic_id,))
            cursor.execute("DELETE FROM student_assessments WHERE topic_id=%s", (topic_id,))
        cursor.execute("DELETE FROM topics WHERE subject_id=%s", (subject_id,))
        cursor.execute("DELETE FROM subjects WHERE subject_id=%s AND teacher_id=%s", (subject_id, teacher_id))
        c.commit()
        print("Subject and all related data deleted successfully!")
    except Exception as e:
        print("Error during deletion:", e)
        c.rollback()

# ---------------- Topic Handling ----------------
def add_topic(teacher_id):
    cursor.execute("SELECT subject_id, Name FROM subjects WHERE teacher_id=%s", (teacher_id,))
    subjects = cursor.fetchall()
    if not subjects:
        print("No subjects available. Please add one first.")
        return
    for s in subjects:
        print(f"{s[0]} - {s[1]}")
    subject_id = input("Enter subject_id: ")
    topic = input("Topic name: ")
    try:
        cursor.execute("INSERT INTO topics(subject_id, topic_name) VALUES(%s,%s)", (subject_id, topic))
        c.commit()
        print("Topic added successfully!")
    except Exception as e:
        print("Failed to add topic:", e)

def delete_topic(teacher_id):
    cursor.execute("""SELECT t.topic_id, t.topic_name 
                      FROM topics t 
                      JOIN subjects s ON t.subject_id=s.subject_id 
                      WHERE s.teacher_id=%s""", (teacher_id,))
    topics = cursor.fetchall()
    if not topics:
        print("No topics to delete.")
        return
    for t in topics:
        print(f"{t[0]} - {t[1]}")
    topic_id = input("Enter topic_id to delete: ")
    confirm = input("Are you sure? This will delete all assessments, MCQs, and student assessments under this topic. (y/n): ").lower()
    if confirm != 'y':
        return

    try:
        cursor.execute("SELECT assessment_id FROM assessments WHERE topic_id=%s", (topic_id,))
        assessments = cursor.fetchall()
        for a in assessments:
            cursor.execute("DELETE FROM mcq_options WHERE assessment_id=%s", (a[0],))
        cursor.execute("DELETE FROM assessments WHERE topic_id=%s", (topic_id,))
        cursor.execute("DELETE FROM student_assessments WHERE topic_id=%s", (topic_id,))
        cursor.execute("DELETE FROM topics WHERE topic_id=%s", (topic_id,))
        c.commit()
        print("Topic and all related data deleted successfully!")
    except Exception as e:
        print("Error:", e)
        c.rollback()

# ---------------- Exam Handling ----------------
def create_exam(teacher_id):
    cursor.execute("SELECT s.subject_id, s.Name FROM subjects s WHERE s.teacher_id=%s", (teacher_id,))
    subjects = cursor.fetchall()
    if not subjects:
        print("No subjects available.")
        return
    for s in subjects:
        print(f"{s[0]} - {s[1]}")
    subject_id = input("Enter subject_id: ")

    cursor.execute("SELECT topic_id, topic_name FROM topics WHERE subject_id=%s", (subject_id,))
    topics = cursor.fetchall()
    if not topics:
        print("No topics found.")
        return
    for t in topics:
        print(f"{t[0]} - {t[1]}")
    topic_id = input("Enter topic_id: ")

    exam_name = input("Enter exam name: ")
    cursor.execute("INSERT INTO exams(topic_id, exam_name) VALUES(%s,%s) RETURNING exam_id", (topic_id, exam_name))
    exam_id = cursor.fetchone()[0]

    print("\nEnter 6 Questions for this Exam:")
    for i in range(1, 7):
        question = input(f"Q{i}: ")
        cursor.execute("INSERT INTO assessments(topic_id, question, exam_id) VALUES(%s,%s,%s) RETURNING assessment_id", (topic_id, question, exam_id))
        assessment_id = cursor.fetchone()[0]
        for opt in ["A","B","C","D"]:
            text = input(f"Option {opt}: ")
            is_correct = input(f"Is {opt} correct? (y/n): ").lower() == 'y'
            cursor.execute("INSERT INTO mcq_options(assessment_id, option_text, is_correct) VALUES(%s,%s,%s)",
                           (assessment_id, f"{opt}. {text}", is_correct))
    c.commit()
    print("Exam with 6 questions created successfully!")

def delete_exam(teacher_id):
    cursor.execute("""
        SELECT e.exam_id, e.exam_name, s.Name, t.topic_name
        FROM exams e
        JOIN topics t ON e.topic_id = t.topic_id
        JOIN subjects s ON t.subject_id = s.subject_id
        WHERE s.teacher_id = %s
    """, (teacher_id,))
    exams = cursor.fetchall()

    if not exams:
        print("No exams found.")
        return

    print("\n--- Exams ---")
    for exam in exams:
        print(f"{exam[0]} - {exam[1]} (Subject: {exam[2]}, Topic: {exam[3]})")

    try:
        exam_id = int(input("Enter exam_id to delete: "))
        confirm = input("Are you sure you want to delete this exam and all its questions? (y/n): ").lower()
        if confirm != "y":
            print("❌ Deletion cancelled.")
            return

        cursor.execute("SELECT assessment_id FROM assessments WHERE exam_id=%s", (exam_id,))
        assessments = cursor.fetchall()

        for (assessment_id,) in assessments:
            cursor.execute("DELETE FROM mcq_options WHERE assessment_id=%s", (assessment_id,))
            cursor.execute("DELETE FROM student_assessments WHERE assessment_id=%s", (assessment_id,))

        cursor.execute("DELETE FROM assessments WHERE exam_id=%s", (exam_id,))
        cursor.execute("DELETE FROM exams WHERE exam_id=%s", (exam_id,))
        c.commit()
        print(" Exam and all related records deleted successfully.")

    except ValueError:
        print("Invalid input. Please enter a valid exam_id.")
    except Exception as e:
        print("Error deleting exam:", e)
        c.rollback()

# ---------------- Progress ----------------
def teacher_view_progress():
    today = datetime.today().date()
    cursor.execute("SELECT student_id, Name FROM student_login")
    students = cursor.fetchall()
    if not students:
        print("No students found.")
        return

    table = []

    for student_id, student_name in students:
        cursor.execute("""
            SELECT t.topic_id, t.topic_name, s.subject_id, s.Name, s.Exam_date
            FROM topics t
            JOIN subjects s ON t.subject_id = s.subject_id
            WHERE s.Exam_date IS NULL OR s.Exam_date >= %s
        """, (today,))
        topics = cursor.fetchall()

        for topic_id, topic_name, subject_id, subject_name, exam_date in topics:
            cursor.execute("SELECT total_hours, hours_needed FROM study_plan WHERE student_id=%s AND topic_id=%s", (student_id, topic_id))
            plan = cursor.fetchone()
            total_hours = float(plan[0]) if plan else 0.0
            hours_needed = float(plan[1]) if plan else 10.0

            cursor.execute("""
                SELECT COUNT(*) 
                FROM student_assessments 
                WHERE student_id=%s AND topic_id=%s AND passed=TRUE
            """, (student_id, topic_id))
            completed_assessments = cursor.fetchone()[0]
            total_assessments = 1

            hour_progress = (total_hours / hours_needed * 100) if hours_needed > 0 else 0
            assess_progress = (completed_assessments / total_assessments * 100)
            overall = round(0.5*hour_progress + 0.5*assess_progress, 2)
            days_left = max((exam_date - today).days, 0) if exam_date else 0

            table.append([student_name, subject_name, topic_name, hours_needed, total_hours, f"{completed_assessments}/{total_assessments}", f"{overall}%", days_left])

    print("\n--- Student Progress ---")
    print(tabulate(table, headers=["Student","Subject","Topic","Hours Needed","Hours Completed","Assessments Done","Overall Progress","Days Left"], tablefmt="fancy_grid"))

def edit_teacher_profile(teacher_id):
    cursor.execute("""
        SELECT Name, user_name, password, contact, college, qualification, email, designation, specialisation, experience
        FROM teacher_login WHERE teacher_id=%s
    """, (teacher_id,))
    teacher = cursor.fetchone()
    if not teacher:
        print("Teacher not found!")
        return

    print("\n--- Edit Profile ---")
    print("Leave blank if you don't want to change a field.\n")

    name = input(f"Name [{teacher[0]}]: ") or teacher[0]
    password = getpass.getpass("Password [hidden]: ") or teacher[2]
    contact = input(f"Contact [{teacher[3]}]: ") or teacher[3]
    college = input(f"College [{teacher[4]}]: ") or teacher[4]
    qualification = input(f"Qualification [{teacher[5]}]: ") or teacher[5]
    email = input(f"Email [{teacher[6]}]: ") or teacher[6]
    designation = input(f"Designation [{teacher[7]}]: ") or teacher[7]
    specialisation = input(f"Specialisation [{teacher[8]}]: ") or teacher[8]
    try:
        experience = input(f"Experience (years) [{teacher[9]}]: ")
        experience = int(experience) if experience.strip() else teacher[9]
    except ValueError:
        experience = teacher[9]

    try:
        cursor.execute("""
            UPDATE teacher_login
            SET Name=%s, password=%s, contact=%s, college=%s, qualification=%s, email=%s, designation=%s, specialisation=%s, experience=%s
            WHERE teacher_id=%s
        """, (name, password, contact, college, qualification, email, designation, specialisation, experience, teacher_id))
        c.commit()
        print("Profile updated successfully!")
    except Exception as e:
        print("Error updating profile:", e)
        c.rollback()
