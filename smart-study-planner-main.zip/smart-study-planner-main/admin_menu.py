from db_connection import connect_db
from datetime import datetime
from tabulate import tabulate
import getpass  # for password masking

c = connect_db()
cursor = c.cursor()

# --------------------- Admin Module ---------------------
def admin_entry():
    while True:
        print("\n--- ADMIN MENU ---")
        print("1. Login\n2. Exit")
        try:
            choice = int(input("Choose option: "))
        except ValueError:
            print("Invalid input. Enter a number.")
            continue

        if choice == 1:
            login_admin()
        elif choice == 2:
            break
        else:
            print("Invalid choice.")

def login_admin():
    username = input("Admin Username: ")
    password = getpass.getpass("Admin Password: ")  # Masked input

    cursor.execute("SELECT admin_id, name FROM admin_login WHERE user_name=%s AND password=%s",
                   (username, password))
    admin = cursor.fetchone()
    if admin:
        print(f"Welcome Admin {admin[1]}")
        admin_menu(admin[0])
    else:
        print("Invalid Admin credentials")

def admin_menu(admin_id):
    while True:
        print("\n--- ADMIN OPTIONS ---")
        print("1. Manage Teachers")
        print("2. Manage Students")
        print("3. View Subjects")
        print("4. manage teacher_requests")
        print("5. exit")
        try:
            choice = int(input("Enter choice: "))
        except ValueError:
            print("Invalid input. Enter a number.")
            continue

        if choice == 1:
            manage_teachers()
        elif choice == 2:
            manage_students()
        elif choice == 3:
            view_subjects()
        elif choice == 4:
            handle_teacher_requests()        
        elif choice == 5:
            break
        else:
            print("Invalid choice.")

# --------------------- Manage Teachers ---------------------
def manage_teachers():
    print("\n--- Teachers List ---")
    cursor.execute("SELECT teacher_id, Name, user_name FROM teacher_login")
    teachers = cursor.fetchall()
    if not teachers:
        print("No teachers found.")
    else:
        print(tabulate(teachers, headers=["ID", "Name", "Username"], tablefmt="grid"))

    print("\n1. Add Teacher\n2. Delete Teacher\n3. Back")
    try:
        choice = int(input("Enter choice: "))
    except ValueError:
        print("Invalid input.")
        return

    if choice == 1:
        name = input("Name: ")
        username = input("Username: ")
        password = getpass.getpass("Password: ")  # Masked input
        cursor.execute("SELECT user_name FROM teacher_login WHERE user_name=%s", (username,))
        if cursor.fetchone():
            print("Username already exists. Try another.")
            return
        cursor.execute("INSERT INTO teacher_login(Name,user_name,password) VALUES(%s,%s,%s)",
                       (name, username, password))
        c.commit()
        print(" Teacher added successfully")
    elif choice == 2:
        tid = input("Enter Teacher ID to delete: ")
        confirm = input("Are you sure you want to delete? (y/n): ").lower()
        if confirm == "y":
            cursor.execute("DELETE FROM teacher_login WHERE teacher_id=%s", (tid,))
            c.commit()
            print(" Teacher deleted successfully")
    elif choice == 3:
        return

# --------------------- Manage Students ---------------------
def manage_students():
    print("\n--- Students List ---")
    cursor.execute("SELECT student_id, Name, user_name FROM student_login")
    students = cursor.fetchall()
    if not students:
        print("No students found.")
    else:
        print(tabulate(students, headers=["ID", "Name", "Username"], tablefmt="grid"))

    print("\n1. Add Student\n2. Delete Student\n3. Back")
    try:
        choice = int(input("Enter choice: "))
    except ValueError:
        print("Invalid input.")
        return

    if choice == 1:
        name = input("Name: ")
        username = input("Username: ")
        password = getpass.getpass("Password: ")  # Masked input
        cursor.execute("SELECT user_name FROM student_login WHERE user_name=%s", (username,))
        if cursor.fetchone():
            print("Username already exists. Try another.")
            return
        cursor.execute("INSERT INTO student_login(Name,user_name,password) VALUES(%s,%s,%s)",
                       (name, username, password))
        c.commit()
        print(" Student added successfully")
    elif choice == 2:
        sid = input("Enter Student ID to delete: ")
        confirm = input("Are you sure you want to delete? (y/n): ").lower()
        if confirm == "y":
            cursor.execute("DELETE FROM student_login WHERE student_id=%s", (sid,))
            c.commit()
            print(" Student deleted successfully")
    elif choice == 3:
        return

# --------------------- View Subjects ---------------------
def view_subjects():
    print("\n--- All Subjects ---")
    cursor.execute("SELECT subject_id, Name, exam_date, teacher_id FROM subjects")
    subjects = cursor.fetchall()
    if not subjects:
        print("No subjects found.")
    else:
        print(tabulate(subjects, headers=["ID", "Subject", "Exam Date", "Teacher ID"], tablefmt="grid"))

#handling teacher requests
def handle_teacher_requests():
    while True:
        print("\n--- Teacher Requests ---")
        print("1. View Pending Requests")
        print("2. View Processed Requests (Approved/Rejected)")
        print("3. Back")
        
        try:
            choice = int(input("Enter choice: "))
        except ValueError:
            print("Invalid input. Enter a number.")
            continue

        if choice == 1:
            cursor.execute("""
                SELECT request_id, name, user_name, email, college, qualification, 
                       designation, specialisation, experience, status 
                FROM teacher_requests 
                WHERE status='pending'
            """)
            requests = cursor.fetchall()

            if not requests:
                print("No pending teacher requests.")
                continue

            print(tabulate(requests, headers=[
                "Req ID","Name","Username","Email","College","Qualification",
                "Designation","Specialisation","Experience","Status"
            ], tablefmt="grid"))

            req_id = input("\nEnter Request ID to process (or press Enter to go back): ")
            if not req_id.strip():
                continue

            action = input("Approve (a) / Reject (r): ").lower()
            if action == 'a':
                cursor.execute("""
                    SELECT name,user_name,password,contact,college,qualification,
                           email,designation,specialisation,experience 
                    FROM teacher_requests 
                    WHERE request_id=%s
                """, (req_id,))
                data = cursor.fetchone()
                if not data:
                    print("Invalid request ID.")
                    continue

                # Check duplicate username
                cursor.execute("SELECT 1 FROM teacher_login WHERE user_name=%s", (data[1],))
                if cursor.fetchone():
                    print(f"Username '{data[1]}' already exists. Auto-rejecting this request.")
                    cursor.execute("UPDATE teacher_requests SET status='rejected' WHERE request_id=%s", (req_id,))
                    c.commit()
                    continue

                # Insert into teacher_login
                cursor.execute("""
                    INSERT INTO teacher_login
                    (Name, user_name, password, contact, college, qualification, 
                     email, designation, specialisation, experience)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                """, data)

                # Update request status (updated_at auto-handled by MySQL)
                cursor.execute("UPDATE teacher_requests SET status='approved' WHERE request_id=%s", (req_id,))
                c.commit()
                print(f" Teacher '{data[0]}' ({data[1]}) approved and added to login table.")

            elif action == 'r':
                cursor.execute("UPDATE teacher_requests SET status='rejected' WHERE request_id=%s", (req_id,))
                c.commit()
                print(" Teacher request rejected.")
            else:
                print("Invalid action.")

        elif choice == 2:
            cursor.execute("""
                SELECT request_id, name, user_name, email, status, updated_at
                FROM teacher_requests 
                WHERE status IN ('approved','rejected')
            """)
            processed = cursor.fetchall()
            if not processed:
                print("No processed requests found.")
            else:
                print(tabulate(processed, headers=[
                    "Req ID","Name","Username","Email","Status","Updated At"
                ], tablefmt="grid"))

        elif choice == 3:
            break
        else:
            print("Invalid choice.")
