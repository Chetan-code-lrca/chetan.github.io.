# main.py

from teacher_menu import teacher_entry
from student_menu import student_entry
from admin_menu import admin_entry

def main():
    while True:
        print("\n-----------------------------------------")
        print("         SMART STUDY PLANNER")
        print("-----------------------------------------")
        print("Choose an option:\n")
        print("1. Teacher")
        print("2. Student")
        print("3. Admin")
        print("4. Exit\n")

        try:
            choice = int(input("Enter your choice: "))
        except ValueError:
            print("Invalid input. Enter a number.\n")
            continue

        if choice == 1:
            teacher_entry()   # PostgreSQL compatible teacher menu
        elif choice == 2:
            student_entry()   # PostgreSQL compatible student menu
        elif choice == 3:
            admin_entry()     # PostgreSQL compatible admin menu
        elif choice == 4:
            print("Exiting Smart Study Planner. Goodbye!")
            break
        else:
            print("Choose a valid option.\n")

if __name__ == "__main__":
    main()
