from db_connection import connect_db
from datetime import datetime
from tabulate import tabulate
from math import ceil
import getpass
from decimal import Decimal

c = connect_db()
cursor = c.cursor()

# ---------------- Student Entry ----------------
def student_entry():
    while True:
        print("\n--- STUDENT ENTRY ---")
        print("1. Login\n2. Register\n3. Exit")
        try:
            choice = int(input("Choose your choice: "))
        except ValueError:
            print("Invalid input. Enter a number.")
            continue

        if choice == 1:
            login_student()
        elif choice == 2:
            register_student()
        elif choice == 3:
            break
        else:
            print("Choose a valid option")

# ---------------- Login/Register ----------------
def login_student():
    username = input("Enter your username: ")
    password = getpass.getpass("Enter your password: ")
    cursor.execute(
        "SELECT student_id, Name FROM student_login WHERE user_name=%s AND password=%s",
        (username, password)
    )
    student = cursor.fetchone()
    if student:
        print(f"\nWelcome, {student[1]}!")
        alert_close_deadlines(student[0])
        student_menu(student[0])
    else:
        print("Invalid credentials")

def register_student():
    print("\n--- STUDENT REGISTRATION ---")
    name = input("Enter your name: ")
    username = input("Enter a username: ")
    password = getpass.getpass("Enter password: ")
    adm_no = input("Enter Admission Number: ")
    phn_no = input("Enter Phone Number: ")
    course = input("Enter Course: ")
    sem = input("Enter Semester: ")
    college = input("Enter College Name: ")
    email = input("Enter Email: ")

    try:
        cursor.execute("SELECT user_name FROM student_login WHERE user_name=%s", (username,))
        if cursor.fetchone():
            print("Username already exists. Choose another.")
            return

        query = """INSERT INTO student_login
                   (name, user_name, password, adm_no, phn_no, course, sem, college, email)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
        values = (name, username, password, adm_no, phn_no, course, sem, college, email)
        cursor.execute(query, values)
        c.commit()
        print("Student registered successfully.\n")
    except Exception as e:
        print("Registration failed:", e)

# ---------------- Close Deadline Alert ----------------
def alert_close_deadlines(student_id):
    today = datetime.today().date()
    cursor.execute("""
        SELECT Name, Exam_date 
        FROM subjects
        WHERE Exam_date IS NOT NULL AND Exam_date >= %s
    """, (today,))
    subjects = cursor.fetchall()
    alerts = []
    for name, exam_date in subjects:
        days_left = (exam_date - today).days
        if 0 <= days_left <= 3:
            alerts.append(f"'{name}' exam is in {days_left} day(s) ({exam_date})!")
    if alerts:
        print("\n--- Upcoming Exams Alert ---")
        for alert in alerts:
            print(alert)
        print("----------------------------\n")

# ---------------- Student Menu ----------------
def student_menu(student_id):
    while True:
        print("\n--- STUDENT MENU ---")
        print("1. View Subjects & Topics")
        print("2. Set Study Plan (with priorities)")
        print("3. View Study Plan")
        print("4. Log Study Hours")
        print("5. Take Assessment")
        print("6. View Progress")
        print("7. Logout")

        try:
            choice = int(input("Enter your choice: "))
        except ValueError:
            print("Invalid input. Enter a number.")
            continue

        if choice == 1:
            view_subjects(student_id)
        elif choice == 2:
            set_study_plan(student_id)
        elif choice == 3:
            view_study_plan(student_id)
        elif choice == 4:
            log_study_hours(student_id)
        elif choice == 5:
            take_assessment(student_id)
        elif choice == 6:
            view_progress(student_id)
        elif choice == 7:
            print("Logged out.")
            break
        else:
            print("Invalid choice!")

# ---------------- View Subjects ----------------
def view_subjects(student_id):
    today = datetime.today().date()
    cursor.execute("""
        SELECT s.subject_id, s.Name, s.Exam_date, t.topic_id, t.topic_name
        FROM subjects s
        LEFT JOIN topics t ON s.subject_id = t.subject_id
        WHERE s.Exam_date IS NULL OR s.Exam_date >= %s
    """, (today,))
    rows = cursor.fetchall()
    if not rows:
        print("No upcoming subjects found")
        return

    table = []
    for row in rows:
        subject_name, topic_name, exam_date = row[1], row[4], row[2]
        exam_date_str = exam_date.strftime("%Y-%m-%d") if exam_date else "N/A"
        table.append([subject_name, topic_name or "—", exam_date_str])
    print("\n--- Subjects & Topics ---")
    print(tabulate(table, headers=["Subject", "Topic", "Exam Date"], tablefmt="fancy_grid"))

# ---------------- Set Study Plan ----------------
def set_study_plan(student_id):
    today = datetime.today().date()
    cursor.execute("""
        SELECT subject_id, Name, Exam_date 
        FROM subjects 
        WHERE Exam_date IS NULL OR Exam_date >= %s
    """, (today,))
    subjects = cursor.fetchall()
    if not subjects:
        print("No subjects available to set study plan")
        return

    for subject_id, subject_name, exam_date in subjects:
        print(f"\n--- Setting plan for subject: {subject_name} ---")
        cursor.execute("SELECT topic_id, topic_name FROM topics WHERE subject_id=%s", (subject_id,))
        topics = cursor.fetchall()
        if not topics:
            print("No topics found for this subject.")
            continue

        total_hours = Decimal(input(f"Enter total study hours you want to allocate for {subject_name}: "))
        print("Set priorities for each topic (High=3, Medium=2, Low=1):")

        priorities = []
        for topic_id, topic_name in topics:
            while True:
                try:
                    priority = int(input(f"Priority for {topic_name}: "))
                    if priority not in [1,2,3]:
                        print("Enter 1, 2 or 3 only.")
                        continue
                    priorities.append((topic_id, topic_name, priority))
                    break
                except ValueError:
                    print("Invalid input, enter a number.")

        total_priority = sum(p[2] for p in priorities)
        days_left = max((exam_date - today).days, 1) if exam_date else 1

        # distribute hours based on priority
        for topic_id, topic_name, priority in priorities:
            hours_needed = (Decimal(priority) / Decimal(total_priority)) * total_hours
            hours_per_day = (hours_needed / Decimal(days_left)) if days_left > 0 else hours_needed

            # PostgreSQL compatible UPSERT
            cursor.execute("""
                INSERT INTO study_plan (student_id, topic_id, total_hours, hours_needed, hours_per_day)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT (student_id, topic_id)
                DO UPDATE SET hours_needed = EXCLUDED.hours_needed, hours_per_day = EXCLUDED.hours_per_day
            """, (student_id, topic_id, Decimal(0), hours_needed, hours_per_day))
            c.commit()

        print(f"Study plan set for {subject_name} successfully!")

# ---------------- View Study Plan ----------------
def view_study_plan(student_id):
    today = datetime.today().date()
    cursor.execute("""
        SELECT t.topic_id, t.topic_name, s.subject_id, s.Name, s.Exam_date, sp.hours_needed, sp.total_hours, sp.hours_per_day
        FROM topics t
        JOIN subjects s ON t.subject_id = s.subject_id
        JOIN study_plan sp ON t.topic_id = sp.topic_id
        WHERE sp.student_id=%s AND (s.Exam_date IS NULL OR s.Exam_date >= %s)
    """, (student_id, today))
    rows = cursor.fetchall()
    if not rows:
        print("No study plan available")
        return

    table = []
    for topic_id, topic_name, subject_id, subject_name, exam_date, hours_needed, total_hours, hours_per_day in rows:
        exam_date_str = exam_date.strftime("%Y-%m-%d") if exam_date else "N/A"
        days_left = max((exam_date - today).days, 0) if exam_date else 0
        table.append([subject_name, topic_name, exam_date_str, hours_needed, total_hours, days_left, round(hours_per_day,2)])

    print("\n--- Topic-wise Study Plan ---")
    print(tabulate(table, headers=["Subject","Topic","Exam Date","Hours Needed","Hours Completed","Days Left","Hours/Day"], tablefmt="fancy_grid"))

# ---------------- Log Study Hours ----------------
def log_study_hours(student_id):
    today = datetime.today().date()

    cursor.execute("""
        SELECT DISTINCT s.subject_id, s.Name, s.Exam_date
        FROM study_plan sp
        JOIN topics t ON sp.topic_id = t.topic_id
        JOIN subjects s ON t.subject_id = s.subject_id
        WHERE sp.student_id=%s AND (s.Exam_date IS NULL OR s.Exam_date >= %s)
    """, (student_id, today))
    subjects = cursor.fetchall()

    if not subjects:
        print("No subjects with pending study plan.")
        return

    for i, subj in enumerate(subjects, 1):
        exam_str = subj[2].strftime("%Y-%m-%d") if subj[2] else "N/A"
        print(f"{i}. {subj[1]} (Exam: {exam_str})")

    try:
        choice = int(input("Select subject to log hours: "))
        if choice < 1 or choice > len(subjects):
            print("Invalid choice.")
            return

        subject = subjects[choice - 1]
        subject_id = subject[0]

        cursor.execute("""
            SELECT sp.plan_id, t.topic_id, t.topic_name, sp.hours_needed, sp.total_hours
            FROM study_plan sp
            JOIN topics t ON sp.topic_id = t.topic_id
            WHERE sp.student_id=%s AND t.subject_id=%s
        """, (student_id, subject_id))
        topics = cursor.fetchall()

        total_remaining = sum([Decimal(t[3] - t[4]) for t in topics])
        if total_remaining <= 0:
            print("All topics for this subject are already completed.")
            return

        hours = Decimal(input(f"Enter hours studied for {subject[1]} (Remaining: {total_remaining}): "))
        if hours <= 0:
            print("Enter a positive value.")
            return
        if hours > total_remaining:
            print(f"You only need {total_remaining} more hours for this subject.")
            return

        for plan_id, topic_id, topic_name, hours_needed, total_hours in topics:
            remaining = Decimal(hours_needed - total_hours)
            if remaining > 0:
                share = (remaining / total_remaining) * hours
                cursor.execute("""
                    UPDATE study_plan
                    SET total_hours = total_hours + %s
                    WHERE plan_id=%s
                """, (share, plan_id))

        c.commit()
        print(f" Logged {hours} hours for {subject[1]} and distributed across topics.")

    except Exception as e:
        print("Error:", e)

# ---------------- Take Assessment ----------------
def take_assessment(student_id):
    today = datetime.today().date()
    cursor.execute("""
        SELECT t.topic_id, t.topic_name, s.Name, s.Exam_date, e.exam_id
        FROM topics t
        JOIN subjects s ON t.subject_id = s.subject_id
        JOIN exams e ON e.topic_id = t.topic_id
        LEFT JOIN student_assessments sa ON sa.topic_id = t.topic_id AND sa.student_id=%s
        WHERE sa.topic_id IS NULL AND (s.Exam_date IS NULL OR s.Exam_date >= %s)
    """, (student_id, today))
    topics = cursor.fetchall()
    if not topics:
        print("No pending assessments available.")
        return

    for i, (topic_id, topic_name, subject_name, exam_date, exam_id) in enumerate(topics, start=1):
        print(f"{i}. {subject_name} - {topic_name} (Exam Date: {exam_date})")
    try:
        choice = int(input("Select topic: "))
        topic_id, topic_name, subject_name, exam_date, exam_id = topics[choice-1]
        if exam_date and exam_date < today:
            print("Deadline passed. Cannot attend assessment.")
            return

        cursor.execute("SELECT assessment_id, question FROM assessments WHERE exam_id=%s", (exam_id,))
        questions = cursor.fetchall()
        if len(questions) < 6:
            print("Assessment not ready yet. Wait for teacher.")
            return

        correct_count = 0
        for idx, (assessment_id, question) in enumerate(questions, start=1):
            print(f"\nQ{idx}: {question}")
            cursor.execute("SELECT option_text, is_correct FROM mcq_options WHERE assessment_id=%s", (assessment_id,))
            options = cursor.fetchall()
            for opt in options:
                print(opt[0])
            answer = input("Your answer (A/B/C/D): ").strip().upper()
            for opt in options:
                if opt[1] and opt[0].startswith(answer + "."):
                    correct_count += 1

        score = (correct_count / len(questions)) * 100
        passed = score >= 50

        cursor.execute("""
            INSERT INTO student_assessments(student_id, topic_id, assessment_id, score, passed)
            VALUES (%s,%s,%s,%s,%s)
        """, (student_id, topic_id, assessment_id, score, passed))
        c.commit()

        print(f"\nAssessment Completed! Score: {score:.2f}%")
        print("Passed!" if passed else "Failed. Try again later.")
    except Exception as e:
        print("Error:", e)

# ---------------- View Progress ----------------
def view_progress(student_id):
    today = datetime.today().date()
    cursor.execute("""
        SELECT t.topic_id, t.topic_name, s.subject_id, s.Name, s.Exam_date
        FROM topics t
        JOIN subjects s ON t.subject_id = s.subject_id
        WHERE s.Exam_date IS NULL OR s.Exam_date >= %s
    """, (today,))
    rows = cursor.fetchall()
    if not rows:
        print("No progress available")
        return

    table = []
    for topic_id, topic_name, subject_id, subject_name, exam_date in rows:
        cursor.execute("SELECT total_hours, hours_needed FROM study_plan WHERE student_id=%s AND topic_id=%s", (student_id, topic_id))
        plan = cursor.fetchone()
        total_hours = Decimal(plan[0]) if plan else Decimal("0.0")
        hours_needed = Decimal(plan[1]) if plan else Decimal("10.0")

        total_assessments = 1
        cursor.execute("SELECT COUNT(*) FROM student_assessments WHERE student_id=%s AND topic_id=%s", (student_id, topic_id))
        completed_assessments = cursor.fetchone()[0]

        hour_progress = float(total_hours / hours_needed * 100) if hours_needed > 0 else 0
        assess_progress = float(completed_assessments / total_assessments * 100)
        overall = round(0.5*hour_progress + 0.5*assess_progress, 2)

        days_left = max((exam_date - today).days, 0) if exam_date else 0

        table.append([subject_name, topic_name, hours_needed, total_hours, f"{completed_assessments}/{total_assessments}", f"{overall}%", days_left])

    print("\n--- Topic-wise Progress ---")
    print(tabulate(table, headers=["Subject","Topic","Hours Needed","Hours Completed","Assessments Done","Overall Progress","Days Left"], tablefmt="fancy_grid"))
